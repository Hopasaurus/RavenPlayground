define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./cirru.snippets");
exports.scope = "cirru";

});
